function setup() {
createCanvas(windowWidth,windowHeight);
}


function draw() {
arc(50, 50, 80, 80, 0, PI + QUARTER_PI);
fill(random(255),random(255), random(255));
}
